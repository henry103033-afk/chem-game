/* ================= 學生端邏輯 ================= */
let currentRankMode = 'class';

async function loadRank() {
		const el = document.getElementById('rankElement').value;
		const list = document.getElementById('rankList');
		const loader = document.getElementById('skeletonLoader');
		list.style.display = 'none';
		loader.style.display = 'block';

		try {
				const res = await fetch(`/api/leaderboard?element=${el}&mode=${currentRankMode}`);
				const data = await res.json();
				list.innerHTML = '';
				if (data.length === 0) {
						list.innerHTML = '<div class="text-center p-3 text-muted">暫無紀錄</div>';
				} else {
						data.forEach((item, index) => {
								let badge = index < 3 ? ['🥇','🥈','🥉'][index] : index + 1;
								let bgClass = index === 0 ? 'bg-warning text-dark' : 'bg-dark border-secondary';
								list.innerHTML += `
								<div class="list-group-item d-flex justify-content-between align-items-center ${bgClass}">
										<div><span class="fw-bold me-3">${badge}</span><span class="fw-bold">${item.nickname}</span></div>
										<div class="text-end"><div class="fw-bold">${item.score}分</div><small>${item.seconds}s</small></div>
								</div>`;
						});
				}
		} catch(e) { console.error(e); } finally { loader.style.display = 'none'; list.style.display = 'block'; }
}

function switchRankTab(mode) {
		currentRankMode = mode;
		document.querySelectorAll('#rankTab .nav-link').forEach(b => b.classList.remove('active'));
		event.target.classList.add('active');
		loadRank();
}

// 遊戲引擎
let questions = [], currentQIndex = 0, score = 0, totalTime = 0, timerInterval, timeLeft = 20, questionLogs = [];

if (typeof CURRENT_ELEMENT !== 'undefined') initGame();

async function initGame() {
		const res = await fetch(`/api/get_questions/${CURRENT_ELEMENT}`);
		questions = await res.json();
		document.getElementById('loading').style.display = 'none';
		document.getElementById('gameArea').style.display = 'block';
		showQuestion();
}

function showQuestion() {
		if (currentQIndex >= questions.length) { endGame(); return; }
		const q = questions[currentQIndex];
		document.getElementById('qIndex').innerText = currentQIndex + 1;
		document.getElementById('qText').innerText = q.text;
		const optsDiv = document.getElementById('optionsArea');
		optsDiv.innerHTML = '';
		q.options.forEach(opt => {
				const btn = document.createElement('button');
				btn.className = 'btn btn-option w-100';
				btn.innerText = `${opt.key}. ${opt.txt}`;
				btn.onclick = () => checkAnswer(btn, opt.key, q.correct, q.id);
				optsDiv.appendChild(btn);
		});
		startTimer();
}

function startTimer() {
		timeLeft = 20;
		clearInterval(timerInterval);
		timerInterval = setInterval(() => {
				timeLeft--;
				document.getElementById('timerText').innerText = timeLeft + "s";
				document.getElementById('timeBar').style.width = (timeLeft / 20 * 100) + "%";
				if (timeLeft <= 0) { clearInterval(timerInterval); handleTimeOut(); }
		}, 1000);
}

function handleTimeOut() {
		const q = questions[currentQIndex];
		document.querySelectorAll('.btn-option').forEach(b => {
				if (b.innerText.startsWith(q.correct)) b.classList.add('btn-correct');
				else b.classList.add('btn-wrong');
				b.disabled = true;
		});
		questionLogs.push({qid: q.id, correct: false});
		totalTime += 20;
		setTimeout(() => { currentQIndex++; showQuestion(); }, 1500);
}

function checkAnswer(btn, selectedKey, correctKey, qid) {
		clearInterval(timerInterval);
		document.querySelectorAll('.btn-option').forEach(b => b.disabled = true);
		let isCorrect = selectedKey === correctKey;
		totalTime += (20 - timeLeft);
		if (isCorrect) { btn.classList.add('btn-correct'); score += 20; }
		else { btn.classList.add('btn-wrong'); document.querySelectorAll('.btn-option').forEach(b => { if (b.innerText.startsWith(correctKey)) b.classList.add('btn-correct'); }); }
		questionLogs.push({qid: qid, correct: isCorrect});
		setTimeout(() => { currentQIndex++; showQuestion(); }, 1200);
}

async function endGame() {
		document.getElementById('gameArea').style.display = 'none';
		document.getElementById('resultArea').style.display = 'block';
		document.getElementById('finalScore').innerText = score;
		document.getElementById('finalTime').innerText = totalTime.toFixed(1);
		await fetch('/api/submit_score', {
				method: 'POST',
				headers: {'Content-Type': 'application/json'},
				body: JSON.stringify({ element: CURRENT_ELEMENT, score: score, seconds: totalTime, logs: questionLogs })
		});
}

/* ================= 老師端邏輯 (含綜合元素支援) ================= */
let wrongChart = null;
window.currentQuestions = [];

async function loadTeacherData() {
		if (!document.getElementById('teacherElement')) return;
		const el = document.getElementById('teacherElement').value;
		const gr = document.getElementById('filterGrade').value;
		const cl = document.getElementById('filterClass').value;

		const res = await fetch(`/api/teacher/data?element=${el}&grade=${gr}&class=${cl}`);
		const data = await res.json();
		window.currentQuestions = data.questions;

		// 1. 成績監控 (含綜合)
		const tbody = document.getElementById('scoreTableBody');
		tbody.innerHTML = data.scores.length ? '' : '<tr><td colspan="4" class="text-center">查無成績資料</td></tr>';
		data.scores.forEach(s => {
				tbody.innerHTML += `<tr><td>${s.classroom}</td><td>${s.seat_num}</td><td>${s.real_name}</td><td><b>${s.score}</b></td></tr>`;
		});

		// 2. 題庫管理 (含跨元素修改)
		const qList = document.getElementById('questionsList');
		qList.innerHTML = '';
		data.questions.forEach(q => {
				qList.innerHTML += `
						<div class="list-group-item d-flex justify-content-between align-items-center">
								<div style="flex: 1;">
										<span class="badge bg-primary me-2">${q.element}</span>
										<strong>${q.q_text}</strong>
										<div class="small text-muted">A:${q.oa} | Ans: <b class="text-success">${q.answer}</b></div>
								</div>
								<div class="ms-3 text-nowrap">
										<button class="btn btn-sm btn-info text-white" onclick="openEditModal(${q.id})">修改</button>
										<button class="btn btn-sm btn-danger" onclick="deleteQ(${q.id})">刪除</button>
								</div>
						</div>`;
		});

		// 3. 作答分析 (綜合模式顯示全體錯誤 TOP 10)
		renderChart(data.chart, el === '綜合' ? '全體題庫錯誤分佈' : `${el} 元素錯誤分佈`);
}

function renderChart(chartData, label) {
		const ctx = document.getElementById('wrongChart');
		if (wrongChart) wrongChart.destroy();
		wrongChart = new Chart(ctx, {
				type: 'bar',
				data: {
						labels: chartData.map(d => `ID:${d.id}`),
						datasets: [{ label: '答錯次數', data: chartData.map(d => d.wrong_count), backgroundColor: '#f56565' }]
				},
				options: { responsive: true, plugins: { title: { display: true, text: label } } }
		});
}

function openEditModal(id = null) {
		const modal = new bootstrap.Modal(document.getElementById('editModal'));
		if (id) {
				const q = window.currentQuestions.find(x => x.id === id);
				document.getElementById('edit_id').value = q.id;
				document.getElementById('edit_ele').value = q.element;
				document.getElementById('edit_q').value = q.q_text;
				document.getElementById('edit_oa').value = q.oa;
				document.getElementById('edit_ob').value = q.ob;
				document.getElementById('edit_oc').value = q.oc;
				document.getElementById('edit_od').value = q.od;
				document.getElementById('edit_oe').value = q.oe;
				document.getElementById('edit_ans').value = q.answer;
		} else {
				document.getElementById('edit_id').value = '';
				document.getElementById('edit_q').value = '';
				document.getElementById('edit_ele').value = document.getElementById('teacherElement').value === '綜合' ? '氫' : document.getElementById('teacherElement').value;
				['oa','ob','oc','od','oe'].forEach(k => document.getElementById('edit_'+k).value = '');
				document.getElementById('edit_ans').value = 'A';
		}
		modal.show();
}

async function saveQuestion() {
		const id = document.getElementById('edit_id').value;
		const payload = {
				id: id,
				ele: document.getElementById('edit_ele').value,
				q: document.getElementById('edit_q').value,
				oa: document.getElementById('edit_oa').value,
				ob: document.getElementById('edit_ob').value,
				oc: document.getElementById('edit_oc').value,
				od: document.getElementById('edit_od').value,
				oe: document.getElementById('edit_oe').value,
				ans: document.getElementById('edit_ans').value
		};
		await fetch('/api/teacher/question', {
				method: id ? 'PUT' : 'POST',
				headers: {'Content-Type': 'application/json'},
				body: JSON.stringify(payload)
		});
		bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
		loadTeacherData();
}

async function deleteQ(id) {
		if(confirm("確定刪除？")) {
				await fetch(`/api/teacher/question?id=${id}`, { method: 'DELETE' });
				loadTeacherData();
		}
}

document.addEventListener("DOMContentLoaded", () => {
		if (document.getElementById('teacherElement')) loadTeacherData();
});